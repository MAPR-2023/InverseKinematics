gource --time-scale 4 --key --file-filter $(cat gource/ignore_files)
