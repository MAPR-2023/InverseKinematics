#include "Python.h"

PyObject*
ik_module_info_create(void);
