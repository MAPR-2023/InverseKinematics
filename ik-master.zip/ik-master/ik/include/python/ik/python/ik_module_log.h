#include "Python.h"

PyObject*
ik_module_log_create(void);
