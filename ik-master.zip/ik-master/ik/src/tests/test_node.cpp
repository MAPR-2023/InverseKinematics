#include "gmock/gmock.h"
#include "ik/ik.h"

#define NAME node

using namespace ::testing;

TEST(NAME, todo)
{
    ASSERT_TRUE(0);
}
