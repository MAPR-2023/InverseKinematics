import ik
import unittest

class TestSolver(unittest.TestCase):
    pass
