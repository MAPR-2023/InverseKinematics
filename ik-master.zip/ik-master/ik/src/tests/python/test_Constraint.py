import ik
import unittest

class TestConstraint(unittest.TestCase):
    pass
