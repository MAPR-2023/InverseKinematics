#include "ik/ik.h"

int main(int argc, char** argv)
{
    return IKAPI.tests.run();
}
