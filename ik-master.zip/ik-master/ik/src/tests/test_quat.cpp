#include "gmock/gmock.h"
#include "ik/ik.h"

#define NAME quat

using namespace ::testing;

TEST(NAME, todo)
{
    ASSERT_TRUE(0);
}
