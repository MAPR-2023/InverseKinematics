#!/bin/sh

for f in include/vtables/*.v; do touch $f; done
